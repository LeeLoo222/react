import { useState, useCallback } from "react";

const Counter = ({ broj }) => {
  const [brojac, setBrojac] = useState(0);

  const uvecaj = useCallback(() => {
    setBrojac((prevBrojac) => prevBrojac + broj);
  }, [broj]);

  /* 
  useCallback(() => {
    setBrojac((prevBrojac) => prevBrojac + 1);
  }, // funkcija koja se sa useCallbackom memorira
  
  [] // lista zavisnosti unutar koje definiramo što se od inputa prati 
     //i ako se promijeni generira novo učitavanje funkcije); 
  */

  return (
    <div>
      <div>Brojac: {brojac}</div>
      <button onClick={uvecaj}>Uvećaj za {broj}</button>
    </div>
  );
};

export default Counter;
