export const HelloFn = (props) => {
  return (
    <div>
      <h1>
        Hello {props.ime} {props.prezime}
      </h1>
      {props.children}
    </div>
  );
};
