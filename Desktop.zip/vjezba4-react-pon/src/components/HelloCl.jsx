import React, { Component } from "react";

export default class HelloCl extends Component {
  render() {
    return (
      <div>
        <h2>
          Hello {this.props.ime} {this.props.prezime}
        </h2>
        {this.props.children}
      </div>
    );
  }
}
