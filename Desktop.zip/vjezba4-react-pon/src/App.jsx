import { HelloFn } from "./components/HelloFn";
import HelloCl from "./components/HelloCl";
import Message from "./components/Message";
import Counter from "./components/Counter";

const App = () => {
  return (
    <div>
      <HelloFn ime="Igor" prezime="Jevremović">
        <p>Učimo React funkcijski prop</p>
      </HelloFn>
      <HelloCl ime="Hrvoje" prezime="Horvat">
        <p>Učimo React klasni prop</p>
      </HelloCl>
      <Message />
      <Counter broj={5} />
    </div>
  );
};

export default App;
