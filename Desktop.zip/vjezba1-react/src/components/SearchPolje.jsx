import React, { Component } from "react";

export default class SearchPolje extends Component {
  render() {
    return (
      <input
        type="search"
        className="search-box"
        placeholder="Traži"
        onChange={this.props.onFilterChange}
      />
    );
  }
}
