import React, { Component } from "react";
import ListaKartica from "./components/ListaKartica";
import SearchPolje from "./components/SearchPolje";

export class App extends Component {
  constructor() {
    super();
    this.state = {
      osobe: [],
      searchPolje: "",
    };
  }

  componentDidMount() {
    fetch("https://reqres.in/api/users").then((res) =>
      res.json().then((objekt) =>
        this.setState(
          () => {
            return { osobe: objekt.data };
          },
          () => console.log(this.state)
        )
      )
    );
  }

  onFilterChange = (event) => {
    const searchPolje = event.target.value.toLocaleLowerCase();
    this.setState(() => {
      return { searchPolje };
    });
  };

  render() {
    const { osobe, searchPolje } = this.state;
    const { onFilterChange } = this;

    const filter = osobe.filter((osoba) => {
      return osoba.first_name.toLocaleLowerCase().includes(searchPolje);
    });

    return (
      <div>
        <SearchPolje onFilterChange={onFilterChange} />
        <ListaKartica osobe={filter} />
      </div>
    );
  }
}

export default App;
