/* import UseEfekt from "./components/UseEfekt"; */
import UseRef from "./components/UseRef";

const App = () => {
  return (
    <>
      {/*  <UseEfekt /> */}
      <UseRef />
    </>
  );
};

export default App;
