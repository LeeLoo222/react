const Header = ({ tekst }) => {
  return (
    <header>
      <p>{tekst}</p>
    </header>
  );
};

export default Header;
