const karticaData = [
  {
    id: 1,
    rating: 5,
    text: "lorem ipsum dolor",
  },
  {
    id: 2,
    rating: 3,
    text: "lorem ipsum dolor",
  },
  {
    id: 3,
    rating: 4,
    text: "lorem ipsum dolor",
  },
  {
    id: 4,
    rating: 2,
    text: "lorem ipsum dolor",
  },
  {
    id: 5,
    rating: 3,
    text: "lorem ipsum dolor",
  },
  {
    id: 6,
    rating: 3,
    text: "lorem ipsum dolor",
  },
];

export default karticaData;
