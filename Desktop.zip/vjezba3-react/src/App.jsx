import { useState } from "react";
import Header from "./components/Header";
import ListaKartica from "./components/ListaKartica";
import karticaData from "./data/karticaData";

const App = () => {
  const [kartica, setKartica] = useState(karticaData);
  return (
    <>
      <Header tekst="NOVI LOGO" />
      <h1>React naslov</h1>
      <ListaKartica kartica={kartica} />
    </>
  );
};

export default App;
